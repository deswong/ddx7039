/home/greg/net/microwin/src/bin/nano-X & sleep 1 & /home/greg/net/microwin/src/bin/nanowm & test/buttons
